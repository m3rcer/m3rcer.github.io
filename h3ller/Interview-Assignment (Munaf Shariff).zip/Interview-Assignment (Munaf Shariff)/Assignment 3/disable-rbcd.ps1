﻿	param ($target)
	
	if ($target -eq $null) {
	
	$target = read-host -Prompt "Please enter a target user or machine account to disable RBCD on"
	}
		
	# OBJECT IDENTIFICATION
	
	# Check if $target is a computer or user object
	if (@(Get-ADComputer $target -ErrorAction SilentlyContinue).Count) {
		Write-Host "[+] $target Computer object exists"
		$tswitch = 1
	}
	elseif (@(Get-ADUser $target -ErrorAction SilentlyContinue).Count) {
		Write-Host "[+] $target User object exists"
		$tswitch = 2
	}
	else { 
		Write-Host "[-] No Object found for $target"
		$tswitch = 3
	}
		
	# SWITCH CONDITIONS
	
	# If $target is a computer object
	if (($tswitch -eq 1)) {
		Write-Host "[+] $target is a computer object"
		$rbcdtarget = Get-ADComputer -AuthType Negotiate -Identity $target -Properties *
		Set-ADComputer -AuthType Negotiate -Identity $rbcdtarget -PrincipalsAllowedToDelegateToAccount $null
		Write-Host "[+] RBCD disabled on $rbcdtarget"
		Write-Host "[+] Validating RBCD set on $rbcdtarget"
		$rbcdtarget = Get-ADComputer -AuthType Negotiate -Identity $target -Properties SamAccountName, DistinguishedName, ServicePrincipalNames, PrincipalsAllowedToDelegateToAccount
		( $env:USERDOMAIN + "\" + $User.SamAccountName )
		$rbcdtarget.DistinguishedName
		""
		"Service Principal Names:"
		foreach( $SPN in $rbcdtarget.ServicePrincipalNames ){ ( "`t`t" + $SPN ) }
		""
		"RBCD:"
		foreach( $RBKCD in $rbcdtarget.PrincipalsAllowedToDelegateToAccount ){ ( "`t`t" + $RBKCD ) }
	}
	
	# If $target is a user object
	if (($tswitch -eq 2)) {
		Write-Host "[+] $target is a user object"
		$rbcdtarget = Get-ADUser -AuthType Negotiate -Identity $target -Properties *
		Set-ADComputer -AuthType Negotiate -Identity $rbcdtarget -PrincipalsAllowedToDelegateToAccount $null
		Write-Host "[+] RBCD disabled on $rbcdtarget "
		Write-Host "[+] Validating RBCD set on $rbcdtarget"
		$rbcdtarget = Get-ADUser -AuthType Negotiate -Identity $target -Properties SamAccountName, DistinguishedName, ServicePrincipalNames, PrincipalsAllowedToDelegateToAccount
		( $env:USERDOMAIN + "\" + $User.SamAccountName )
		$rbcdtarget.DistinguishedName
		""
		"Service Principal Names:"
		foreach( $SPN in $rbcdtarget.ServicePrincipalNames ){ ( "`t`t" + $SPN ) }
		""
		"RBCD:"
		foreach( $RBKCD in $rbcdtarget.PrincipalsAllowedToDelegateToAccount ){ ( "`t`t" + $RBKCD ) }
	}