﻿param ($target, $DelegatedAccount)
	
if ($target -eq $null) {
	
$target = read-host -Prompt "Please enter a target user or machine account to enable RBCD on"
}
	
if ($DelegatedAccount -eq $null) {
	
$DelegatedAccount = read-host -Prompt "Please enter a target user or machine account to allow delegation to the target --> $target"
}
	
# OBJECT IDENTIFICATION
	
# Check if $target is a computer or user object
if (@(Get-ADComputer $target -ErrorAction SilentlyContinue).Count) {
	Write-Host "[+] $target Computer object exists"
	$tswitch = 1
}
elseif (@(Get-ADUser $target -ErrorAction SilentlyContinue).Count) {
	Write-Host "[+] $target User object exists"
	$tswitch = 2
}
else { 
	Write-Host "[-] No Object found for $target"
	$tswitch = 3
}
	
# Check if $DelegatedAccount is a computer or user object
if (@(Get-ADComputer $DelegatedAccount -ErrorAction SilentlyContinue).Count) {
	Write-Host "[+] $DelegatedAccount Computer object exists"
	$dswitch = 1
}
elseif (@(Get-ADUser $DelegatedAccount -ErrorAction SilentlyContinue).Count) {
	Write-Host "[+] $DelegatedAccount User object exists"
	$dswitch = 2
}
else {
	Write-Host "[+] No Object found for $DelegatedAccount"
	$dswitch = 3
}
	
# SWITCH CONDITIONS
	
# If both $DelegatedAccount and $target are computer objects
if (($tswitch -eq 1) -and ($dswitch -eq 1)) {
	Write-Host "[+] Both $DelegatedAccount and $target are computer objects"
	$rbcdtarget = Get-ADComputer -AuthType Negotiate -Identity $target -Properties *
	$rbcduser = Get-ADComputer -AuthType Negotiate -Identity $DelegatedAccount -Properties *
	Set-ADComputer -AuthType Negotiate -Identity $rbcdtarget -PrincipalsAllowedToDelegateToAccount $rbcduser
	Write-Host "[+] RBCD set on $rbcdtarget allowing $rbcduser delegation rights"
	Write-Host "[+] Validating RBCD set on $rbcdtarget"
	$rbcdtarget = Get-ADComputer -AuthType Negotiate -Identity $target -Properties SamAccountName, DistinguishedName, ServicePrincipalNames, PrincipalsAllowedToDelegateToAccount
	( $env:USERDOMAIN + "\" + $User.SamAccountName )
	$rbcdtarget.DistinguishedName
	""
	"Service Principal Names:"
	foreach( $SPN in $rbcdtarget.ServicePrincipalNames ){ ( "`t`t" + $SPN ) }
	""
	"RBCD:"
	foreach( $RBKCD in $rbcdtarget.PrincipalsAllowedToDelegateToAccount ){ ( "`t`t" + $RBKCD ) }
}
	
# If $DelegatedAccount is a computer object and $target is a user object
if (($tswitch -eq 2) -and ($dswitch -eq 1)) {
	Write-Host "[+] $DelegatedAccount is a computer object and $target is a user object"
	$rbcdtarget = Get-ADUser -AuthType Negotiate -Identity $target -Properties *
	$rbcduser = Get-ADComputer -AuthType Negotiate -Identity $DelegatedAccount -Properties *
	Set-ADComputer -AuthType Negotiate -Identity $rbcdtarget -PrincipalsAllowedToDelegateToAccount $rbcduser
	Write-Host "[+] RBCD set on $rbcdtarget allowing $rbcduser delegation rights"
	Write-Host "[+] Validating RBCD set on $rbcdtarget"
	$rbcdtarget = Get-ADUser -AuthType Negotiate -Identity $target -Properties SamAccountName, DistinguishedName, ServicePrincipalNames, PrincipalsAllowedToDelegateToAccount
	( $env:USERDOMAIN + "\" + $User.SamAccountName )
	$rbcdtarget.DistinguishedName
	""
	"Service Principal Names:"
	foreach( $SPN in $rbcdtarget.ServicePrincipalNames ){ ( "`t`t" + $SPN ) }
	""
	"RBCD:"
	foreach( $RBKCD in $rbcdtarget.PrincipalsAllowedToDelegateToAccount ){ ( "`t`t" + $RBKCD ) }
}
	
# If $DelegatedAccount is a user object and $target is a computer object
if (($tswitch -eq 1) -and ($dswitch -eq 2)) {
	Write-Host "[+] $DelegatedAccount is a user object and $target is a computer object"
	$rbcdtarget = Get-ADComputer -AuthType Negotiate -Identity $target -Properties *
	$rbcduser = Get-ADUser -AuthType Negotiate -Identity $DelegatedAccount -Properties *
	Set-ADComputer -AuthType Negotiate -Identity $rbcdtarget -PrincipalsAllowedToDelegateToAccount $rbcduser
	Write-Host "[+] RBCD set on $rbcdtarget allowing $rbcduser delegation rights"
	Write-Host "[+] Validating RBCD set on $rbcdtarget"
	$rbcdtarget = Get-ADComputer -AuthType Negotiate -Identity $target -Properties SamAccountName, DistinguishedName, ServicePrincipalNames, PrincipalsAllowedToDelegateToAccount
	( $env:USERDOMAIN + "\" + $User.SamAccountName )
	$rbcdtarget.DistinguishedName
	""
	"Service Principal Names:"
	foreach( $SPN in $rbcdtarget.ServicePrincipalNames ){ ( "`t`t" + $SPN ) }
	""
	"RBCD:"
	foreach( $RBKCD in $rbcdtarget.PrincipalsAllowedToDelegateToAccount ){ ( "`t`t" + $RBKCD ) }
}
	
# If $DelegatedAccount is a user object and $target is a user object
if (($tswitch -eq 2) -and ($dswitch -eq 2)) { 
	Write-Host "[+] $DelegatedAccount is a user object and $target is a user object"
	$rbcdtarget = Get-ADUser -AuthType Negotiate -Identity $target -Properties *
	$rbcduser = Get-ADUser -AuthType Negotiate -Identity $DelegatedAccount -Properties *
	Set-ADComputer -AuthType Negotiate -Identity $rbcdtarget -PrincipalsAllowedToDelegateToAccount $rbcduser
	Write-Host "[+] RBCD set on $rbcdtarget allowing $rbcduser delegation rights"
	Write-Host "[+] Validating RBCD set on $rbcdtarget"
	$rbcdtarget = Get-ADUser -AuthType Negotiate -Identity $target -Properties SamAccountName, DistinguishedName, ServicePrincipalNames, PrincipalsAllowedToDelegateToAccount
	( $env:USERDOMAIN + "\" + $User.SamAccountName )
	$rbcdtarget.DistinguishedName
	""
	"Service Principal Names:"
	foreach( $SPN in $rbcdtarget.ServicePrincipalNames ){ ( "`t`t" + $SPN ) }
	""
	"RBCD:"
	foreach( $RBKCD in $rbcdtarget.PrincipalsAllowedToDelegateToAccount ){ ( "`t`t" + $RBKCD ) }
}
